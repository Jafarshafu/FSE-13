export interface MovieDto {
    movie_Name: string;             // Name of the movie
    theatre_Name: string;           // Name of the theatre
    no_of_Tickets_Available: number; // Number of tickets available
    ticket_Status: string;
    show_Time: Date; 
            // Show time of the movie
}
