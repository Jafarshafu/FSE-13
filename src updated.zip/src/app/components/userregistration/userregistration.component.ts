import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { User } from 'src/app/model/user.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-userregistration',
  templateUrl: './userregistration.component.html',
  styleUrls: ['./userregistration.component.css'],
})
export class UserregistrationComponent implements OnInit {
  registrationForm: FormGroup;

  constructor(private userService: UserService, private fb: FormBuilder) {
    // Initialize the form
    this.registrationForm = this.fb.group({
      First_Name: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(20)]],
      Last_Name: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(20)]],
      Email: ['', [Validators.required, Validators.email]],
      Login_Id: ['', [Validators.required]],
      Password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(20)]],
      Confrim_Password: ['', [Validators.required]],
    }, {
      validators: this.passwordMatchValidator
    });
  }

  ngOnInit(): void {}

  passwordMatchValidator(form: FormGroup) {
    return form.get('Password')?.value === form.get('Confrim_Password')?.value
      ? null : { 'mismatch': true };
  }

  onSubmit(): void {
    if (this.registrationForm.valid) {
      const user: User = this.registrationForm.value;
      this.userService.registerUser(user).subscribe(
        (response) => {
          console.log('Registration successful:', response);
          alert('Registration successful!'); // Show success message
          this.registrationForm.reset(); // Reset form after successful registration
        },
        (error) => {
          console.error('Registration failed:', error);
          const errorMessage = error.error.message || 'An error occurred. Please try again.';
          alert(`Error: ${errorMessage}`); // Show error message
        }
      );
    } else {
      console.error('Form is invalid');
      alert('Please fill in all required fields correctly.');
    }
  }

  get formControls() {
    return this.registrationForm.controls;
  }
}
