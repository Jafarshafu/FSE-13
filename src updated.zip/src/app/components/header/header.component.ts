import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { SearchService } from '../../services/search.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  searchQuery: string = ''; // Holds the search input

  constructor(private router: Router, private searchService: SearchService) {}

  navigateHome(): void {
    this.router.navigate(['/home']);
  }

  onSearch(): void {
    // Emit the search query through the SearchService
    this.searchService.emitSearch(this.searchQuery);
  }

  // Optional: Clear the search input field after emitting the event
  clearSearch(): void {
    this.searchQuery = '';
  }
}
