import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
  loginForm: FormGroup;
  loginError: string | null = null;
  isAdminLoggedIn: boolean = false; // Track admin login status

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      adminLoginId: ['', Validators.required],
      adminPassword: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    // Subscribe to admin login status
    this.authService.isAdminLoggedIn$.subscribe(loggedIn => {
      this.isAdminLoggedIn = loggedIn;
    });
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      const { adminLoginId, adminPassword } = this.loginForm.value;

      this.authService.handleAdminLogin(adminLoginId, adminPassword).subscribe({
        next: (response) => {
          if (response === "Login Successful") {
            this.loginError = null; // Clear any previous errors
            // Navigate to home
            this.router.navigate(['/home']);
          } else {
            this.loginError = response;
          }
        },
        error: (err) => {
          console.error('Login failed', err);
          this.loginError = 'An error occurred. Please try again.';
        }
      });
    }
  }

  logout(): void {
    this.authService.logout(); // Update admin login status
    this.router.navigate(['/admin-login']); // Redirect to admin login page
  }
}
