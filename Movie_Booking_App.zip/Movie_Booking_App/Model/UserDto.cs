﻿namespace Movie_Booking_App.Model
{
    public class UserDto
    {
        public string Login_Id { get; set; }

    }
}
