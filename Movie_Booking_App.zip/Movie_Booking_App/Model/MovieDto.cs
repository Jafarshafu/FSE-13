﻿namespace Movie_Booking_App.Model
{
    public class MovieDto
    {
        public string Movie_Name { get; set; }
        public string Theatre_Name { get; set; }
        public int No_of_Tickets_Available { get; set; }
        public DateTime Show_Time { get; set; }
        public string Ticket_Status { get; set; }

    }
}
