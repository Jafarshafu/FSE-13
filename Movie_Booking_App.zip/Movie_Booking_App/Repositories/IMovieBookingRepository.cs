﻿using MongoDB.Bson;
using Movie_Booking_App.Model;

namespace Movie_Booking_App.Repositories
{
    public interface IMovieBookingRepository 
    {
        Task<string> AddMovie(Movie _moviedetails);
        Task<List<MovieDto>> GetAllMovies();
        Task<List<MovieDto>> GetMovieByName(string moviename);
        Task<Int32> MovieTicketAvailability(string moviename);
        Task<Int32> BookedTickets(string moviename);
        Task<string> UpdateMovieTicketAvailability(string moviename);
        Task<string> TicketBooking(string moviename , int No_of_Tickets);
        Task<string> DeleteExistingMovie(string moviename);
        //Task<IEnumerable<MovieBookingRepository>> GetAllMovies();
    }
}
