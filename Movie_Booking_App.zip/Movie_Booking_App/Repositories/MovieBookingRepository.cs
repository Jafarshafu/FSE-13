﻿using MongoDB.Bson;
using MongoDB.Driver;
using Movie_Booking_App.Model;
using System.Collections.Generic;

namespace Movie_Booking_App.Repositories 
{
    public class MovieBookingRepository : IMovieBookingRepository
    {
        private readonly IMongoCollection<Movie> _movie;
        private readonly IConfiguration _configuration;
        public MovieBookingRepository(IMongoClient client, IConfiguration configuration)
        {
            _configuration = configuration;
            string? dbNmae = configuration["Database:Name"];
            var database = client.GetDatabase("MovieBookingDB");
            var collection = database.GetCollection<Movie>(nameof(Movie));
            _movie = collection;
        }

        /// <summary>
        /// Add Movie
        /// </summary>
        /// <param name="_moviedetails"></param>
        /// <returns>New Movie Status</returns>
        public async Task<string> AddMovie(Movie _moviedetails)
        {
            try
            {
                if (_moviedetails != null)
                {
                    await _movie.InsertOneAsync(_moviedetails);
                    return "Movie details Add successfully";
                }
                else
                    return "Please enter movie details";
            }
             catch (Exception ex)
            {
                Console.WriteLine("Unable to Add movie exception", ex);
                return "";
            }
        }

        /// <summary>
        /// All Available movies
        /// </summary>
        /// <returns>list of movies</returns>
        public async Task<List<MovieDto>> GetAllMovies()
        {
            try
            {
                var result = await _movie.Find(movie => true).Project(m => new MovieDto
                {
                    Movie_Name = m.Movie_Name,
                    Theatre_Name = m.Theatre_Name,
                    No_of_Tickets_Available = m.No_of_Tickets_Available,
                    Ticket_Status= m.Ticket_Status,
                    Show_Time = m.Show_Time
                }).ToListAsync();
                return result;
            }
             catch (Exception ex)
            {
                Console.WriteLine("Unable to get all movie exception", ex);
                return new List<MovieDto>();
            }
        }
        
        /// <summary>
        /// Get Movie
        /// </summary>
        /// <param name="moviename"></param>
        /// <returns>Movie Details</returns>
        public async Task<List<MovieDto>> GetMovieByName(string moviename)
        {
            try
            {
                var searchmoviefilter = Builders<Movie>.Filter.Eq(m => m.Movie_Name, moviename);
                var searchmovieresult = await _movie.Find(searchmoviefilter).Project(m => new MovieDto
                {
                    Movie_Name = m.Movie_Name,
                    Theatre_Name = m.Theatre_Name,
                    No_of_Tickets_Available = m.No_of_Tickets_Available,
                    Show_Time = m.Show_Time
                }).ToListAsync();
                return searchmovieresult;
            }
             catch (Exception ex)
            {
                Console.WriteLine("Unable to get movie exception", ex);
                return new List<MovieDto>();
            }

        }
        /// <summary>
        /// Ticket Availability
        /// </summary>
        /// <param name="moviename"></param>
        /// <returns>Available tickets</returns>
        public async Task<Int32> MovieTicketAvailability(string moviename)
        {
            try
            {
                var result = _movie.Find(Builders<Movie>.Filter.Eq(m => m.Movie_Name, moviename)).FirstOrDefaultAsync().Result.No_of_Tickets_Available;
                return result;
            }
             catch (Exception ex)
            {
                Console.WriteLine("Unable to fetch ticket availability movie exception", ex);
                return 0;
            }
        }
        /// <summary>
        /// To get total tickets
        /// </summary>
        /// <param name="moviename"></param>
        /// <returns>
        /// Total tickets</returns>
        private async Task<Int32> TotalTickets(string moviename)
        {
            try
            {
                var Total_Tickets = _movie.Find(Builders<Movie>.Filter.Eq(m => m.Movie_Name, moviename)).FirstOrDefaultAsync().Result.Total_Tickets;
                return Total_Tickets;
            }
             catch (Exception ex)
            {
                Console.WriteLine("Unable to fetch total movie exception", ex);
                return 0;
            }
        }
        /// <summary>
        ///To fetch booked tickets
        /// </summary>
        /// <param name="moviename"></param>
        /// <returns>No of Booked tickets</returns>
        public async Task<Int32> BookedTickets(string moviename)
        {
            try
            {
                var Booked_Tickets = await TotalTickets(moviename) - await MovieTicketAvailability(moviename);
                return Booked_Tickets;
            }
             catch (Exception ex)
            {
                Console.WriteLine("Unable to fetch booked tickets movie exception", ex);
                return 0;
            }
        }
        /// <summary>
        /// Update available tickets for movie
        /// </summary>
        /// <param name="moviename"></param>
        /// <returns>
        /// Tickets updation status</returns>
        public async Task<string> UpdateMovieTicketAvailability(string moviename )
        {
            try
            {
                var updatemovieticket_filter = Builders<Movie>.Filter.Eq(u => u.Movie_Name, moviename);
                var Ticket_check = await TotalTickets(moviename) - await BookedTickets(moviename);
                if (Ticket_check > 0)
                {
                    var Ticket_status = Builders<Movie>.Update.Set(m => m.Ticket_Status, "Book ASAP");
                    var Ticket_status_Result = await _movie.UpdateOneAsync(updatemovieticket_filter, Ticket_status);
                    return "ASAP Updated successfully";
                }
                else
                {
                    var Ticket_status = Builders<Movie>.Update.Set(m => m.Ticket_Status, "SOLD OUT");
                    var Ticket_status_Result = await _movie.UpdateOneAsync(updatemovieticket_filter, Ticket_status);
                    return "SOLD OUT Updated successfully";
                }
            }
             catch (Exception ex)
            {
                Console.WriteLine("Unable to update movie exception", ex);
                return "";
            }
        }
        /// <summary>
        /// TIcket Booking
        /// </summary>
        /// <param name="moviename"></param>
        /// <param name="No_of_Tickets"></param>
        /// <returns>Booking status</returns>
        public async Task<string> TicketBooking(string moviename , int No_of_Tickets)
        {
            try
            {
                var Tickets_Available = await TotalTickets(moviename) - await BookedTickets(moviename);
                if ((Tickets_Available > 0) && (No_of_Tickets <= Tickets_Available))
                {
                    var current_available_tickets = await TotalTickets(moviename) - (No_of_Tickets);
                    UpdateMovieTickets(moviename, current_available_tickets);
                    await UpdateMovieTicketAvailability(moviename);
                    return "Tickets booked successfully";
                }
                else if (Tickets_Available > 0)
                {
                    var available_tickets = Tickets_Available.ToString();
                    return $"available tickets are {available_tickets}";
                }
                else
                    return "SOLD OUT";
            }
             catch (Exception ex)
            {
                Console.WriteLine("Unable to Book movie ticket exception", ex);
                return "";
            }
        }
        /// <summary>
        /// To Update Movie tickets
        /// </summary>
        /// <param name="moviename"></param>
        /// <param name="current_available_tickets"></param>
        private void UpdateMovieTickets(string moviename, int current_available_tickets)
        {
            try
            {
                var updatemovieticket_filter = Builders<Movie>.Filter.Eq(u => u.Movie_Name, moviename);

                var Current_Available_Tickets = Builders<Movie>.Update.Set(m => m.No_of_Tickets_Available, current_available_tickets);
                _movie.UpdateOneAsync(updatemovieticket_filter, Current_Available_Tickets);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to update movie exception", ex);
            }

        }
        /// <summary>
        /// Delete Existing Movie
        /// </summary>
        /// <param name="moviename"></param>
        /// <returns>Deletion Status</returns>
        public async Task<string> DeleteExistingMovie(string moviename)
        {
            try
            {
                var deletemovie_filter = Builders<Movie>.Filter.Eq(d => d.Movie_Name, moviename);
                var result = await _movie.DeleteOneAsync(deletemovie_filter);
                if (result.DeletedCount == 0)
                    return "Movie details not available";
                else
                    return "Movie deleted successfully";
            }
            catch(Exception ex)
            {
                Console.WriteLine("Unable to delete movie exception",ex);
                return "";
            }
            
        }
    }
}
