﻿using DnsClient.Internal;
using Microsoft.AspNetCore.Mvc;
using Movie_Booking_App.Model;
using Movie_Booking_App.Repositories;

namespace Movie_Booking_App.Controllers
{
    [Route("api/v1.0/moviebooking")]
    [ApiController]
    public class MovieBookingController : ControllerBase
    {
        private readonly IMovieBookingRepository _moviebookingrepository;
        private readonly ILogger<MovieBookingController> _logger;
        public MovieBookingController(IMovieBookingRepository moviebookingrepository , ILogger<MovieBookingController> logger)
        {
            _logger = logger;
            _moviebookingrepository = moviebookingrepository;
        }
        /// <summary>
        /// Add New Movie to the database
        /// </summary>
        /// <param name="_moviedetails"></param>
        /// <returns>New Movie Confirmation</returns>
        [HttpPost]
        [Route("addmovie")]
        public async Task<string> AddMovie([FromBody] Movie _moviedetails)
        {
            if(_moviedetails == null)
            {
                _logger.LogError("Add Movie Controller: Movie details are null");
                return " Movie details to add are null";
            }
            else
            {
                _logger.LogInformation("Add Movie Controller: Adding Movie details");
                var result = await _moviebookingrepository.AddMovie(_moviedetails);
                return result;
            }
            
        }
        /// <summary>
        /// Fetching all available movies
        /// </summary>
        /// <returns>All Available Movies</returns>
        [HttpGet]
        [Route("all")]
        public async Task<ActionResult<List<MovieDto>>> All()
        {
            _logger.LogDebug("AVailable Movies Controller: Presenting all available Movies");
            var result = await _moviebookingrepository.GetAllMovies();
            return Ok(result);
        }
        /// <summary>
        /// Fetching availabke movie by movie name
        /// </summary>
        /// <param name="Moviename"></param>
        /// <returns>Movie details</returns>
        [HttpGet]
        [Route("movies/search/<moviename>")]
        public async Task<ActionResult<MovieDto>> GetMovieByName(string Moviename)
        {
            if(Moviename== null) 
            {
                _logger.LogError("Search Movie Controller: Movie name is null");
                return BadRequest("Movie name should not be empty");

            }
            else
            {
                _logger.LogDebug($"{Moviename}");
                var result = await _moviebookingrepository.GetMovieByName(Moviename);
                return Ok(result);
            }
        }
        /// <summary>
        /// Ticket Booking
        /// </summary>
        /// <param name="moviename"></param>
        /// <param name="No_of_Tickets"></param>
        /// <returns>Booking status</returns>
        [HttpPost]
        [Route("{moviename}/add")]
        public async Task<string> Add(string moviename, int No_of_Tickets)
        {
            if (moviename == null || No_of_Tickets == 0)
            {
                _logger.LogError("Book Ticket Controller: Movie name Or Tickets are null");
                return "Please provide valid data for movie name or tickets required";

            }
            else
            {
                _logger.LogDebug("Booking Tickets");
                var result = await _moviebookingrepository.TicketBooking(moviename, No_of_Tickets);
                return result.ToString();
            }
            
        }
        /// <summary>
        /// Delete Existing Movie
        /// </summary>
        /// <param name="moviename"></param>
        /// <returns>Deletion status</returns>
        [HttpDelete]
        [Route("{moviename}/delete")]
        public async Task<string> Delete(string moviename)
        {
            if(moviename == null)
            {
                _logger.LogError("Delete Movie Controller: please provide movie name");
                return "Movie name is empty";
            }
            else
            {
                _logger.LogInformation("Delete Movie");
                var result = await _moviebookingrepository.DeleteExistingMovie(moviename);
                return result;
            }
        }
    }
}
