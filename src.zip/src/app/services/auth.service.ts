import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, BehaviorSubject, tap, catchError, throwError } from 'rxjs';
import { MovieDto } from '../model/movie.dto';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private baseUrl = 'https://localhost:44313/api/v1.0/moviebooking';
  private loginUrl = `${this.baseUrl}/login`;
  private forgotPasswordUrl = `${this.baseUrl}/`;
  private adminLoginUrl = `${this.baseUrl}/adminlogin`;
  private searchUrl = `${this.baseUrl}/movies/search/`;
  private allMoviesUrl = `${this.baseUrl}/all`; // URL for fetching all movies

  // BehaviorSubjects to track login status
  private loginStatusSubject = new BehaviorSubject<boolean>(this.isLoggedIn());
  isLoggedIn$ = this.loginStatusSubject.asObservable();
  private adminStatusSubject = new BehaviorSubject<boolean>(this.isAdminLoggedIn());
  isAdminLoggedIn$ = this.adminStatusSubject.asObservable();

  constructor(private http: HttpClient) {}

  // User login
  login(loginId: string, password: string): Observable<string> {
    const params = new HttpParams()
      .set('Login_Id', loginId)
      .set('Password', password);
    return this.http.get<string>(this.loginUrl, { params, responseType: 'text' as 'json' });
  }

  // Admin login
  adminLogin(adminLoginId: string, adminPassword: string): Observable<string> {
    const params = new HttpParams()
      .set('admin_login_id', adminLoginId)
      .set('admin_password', adminPassword);
    return this.http.get<string>(this.adminLoginUrl, { params, responseType: 'text' as 'json' });
  }

  // Forgot password
  forgotPassword(username: string): Observable<string> {
    return this.http.get<string>(`${this.forgotPasswordUrl}${username}/forgot`, { responseType: 'text' as 'json' });
  }

  // Update login status in local storage and emit new status
  updateLoginStatus(isLoggedIn: boolean): void {
    localStorage.setItem('isLoggedIn', JSON.stringify(isLoggedIn));
    this.loginStatusSubject.next(isLoggedIn);
  }

  // Check if user is logged in
  isLoggedIn(): boolean {
    return JSON.parse(localStorage.getItem('isLoggedIn') || 'false');
  }

  // Update admin status in local storage and emit new status
  updateAdminStatus(isAdmin: boolean): void {
    localStorage.setItem('isAdminLoggedIn', JSON.stringify(isAdmin));
    this.adminStatusSubject.next(isAdmin);
  }

  // Check if admin is logged in
  isAdminLoggedIn(): boolean {
    return JSON.parse(localStorage.getItem('isAdminLoggedIn') || 'false');
  }

  // Update password
  updatePassword(updateDetails: any): Observable<string> {
    return this.http.put<string>(`${this.loginUrl}updatepassword`, updateDetails, { responseType: 'text' as 'json' });
  }

  // Handle user login with error handling
  handleUserLogin(loginId: string, password: string): Observable<string> {
    return this.login(loginId, password).pipe(
      tap(response => {
        if (response === "Login Successful") {
          this.updateLoginStatus(true);
          this.updateAdminStatus(false);
        }
      }),
      catchError(err => {
        console.error('User login error', err);
        return throwError(err);
      })
    );
  }

  // Handle admin login with error handling
  handleAdminLogin(adminLoginId: string, adminPassword: string): Observable<string> {
    return this.adminLogin(adminLoginId, adminPassword).pipe(
      tap(response => {
        if (response === "Login Successful") {
          this.updateAdminStatus(true);
          this.updateLoginStatus(false);
        }
      }),
      catchError(err => {
        console.error('Admin login error', err);
        return throwError(err);
      })
    );
  }

  // Logout functionality
  logout(): void {
    this.updateLoginStatus(false);
    this.updateAdminStatus(false);
  }

  // Search for a movie by name
  searchMovie(movieName: string): Observable<MovieDto[]> {
    return this.http.get<MovieDto[]>(`${this.searchUrl}${movieName}`).pipe(
      catchError(err => {
        console.error('Search movie error', err);
        return throwError(err);
      })
    );
  }

  // New method to fetch all movies
  getAllMovies(): Observable<MovieDto[]> {
    return this.http.get<MovieDto[]>(this.allMoviesUrl).pipe(
      catchError(err => {
        console.error('Fetch all movies error', err);
        return throwError(err);
      })
    );
  }

  bookTickets(moviename: string, noOfTickets: number): Observable<string> {
    const url = `${this.baseUrl}/${moviename}/add`; // Construct the URL based on your backend
    const params = new HttpParams().set('No_of_Tickets', noOfTickets.toString());
    
    return this.http.post(url, null, { params, responseType: 'text' }) // Ensure responseType is 'text'
      .pipe(
        catchError(err => {
          console.error('Booking error', err);
          return throwError(err);
        })
      );
  }

  addMovie(movie: any): Observable<string> {
    const url = `${this.baseUrl}/addmovie`; // Adjust this URL based on your backend
    return this.http.post<string>(url, movie, { responseType: 'text' as 'json' });
}

deleteMovie(movieName: string): Observable<string> {
  const url = `${this.baseUrl}/${movieName}/delete`;
  return this.http.delete<string>(url, { responseType: 'text' as 'json' });
}
updateTicketStatus(movieName: string): Observable<string> {
  const url = `${this.baseUrl}/${movieName}/update`;
  return this.http.put<string>(url, { movieName, responseType: 'text' as 'json' }); 
}

getBookedTickets(moviename: string): Observable<number> {
  return this.http.get<number>(`${this.baseUrl}/bookedtickets?moviename=${moviename}`);
}

}
