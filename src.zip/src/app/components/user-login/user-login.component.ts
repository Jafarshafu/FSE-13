import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  loginForm: FormGroup;
  loginError: string | null = null;
  isLoggedIn: boolean = false; // Track login status

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      loginId: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    // Subscribe to login status
    this.authService.isLoggedIn$.subscribe(loggedIn => {
      this.isLoggedIn = loggedIn;
    });
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      const { loginId, password } = this.loginForm.value;

      this.authService.handleUserLogin(loginId, password).subscribe({
        next: (response) => {
          if (response === "Login Successful") {
            this.loginError = null; // Clear any previous errors
            
            // Redirect to home page
            this.router.navigate(['/home']);
          } else {
            this.loginError = response;
          }
        },
        error: (err) => {
          console.error('Login failed', err);
          this.loginError = 'An error occurred. Please try again.';
        }
      });
    }
  }

  forgotPassword(): void {
    const loginId = this.loginForm.get('loginId')?.value;
    if (loginId) {
      this.authService.forgotPassword(loginId).subscribe({
        next: (response) => {
          alert(`Your password is: ${response}`); // Alert the user with the password
        },
        error: (err) => {
          console.error('Failed to fetch password', err);
          alert('An error occurred while fetching the password.');
        }
      });
    } else {
      alert('Please enter your Login ID.');
    }
  }

  logout(): void {
    this.authService.logout(); // Update login status for both user and admin
    this.router.navigate(['/login']); // Redirect to login page
  }
}
