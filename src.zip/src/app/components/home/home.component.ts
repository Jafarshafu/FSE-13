 import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { SearchService } from '../../services/search.service'; 
import { MovieDto } from 'src/app/model/movie.dto';
import { firstValueFrom } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  movies: MovieDto[] = []; 
  isUserLoggedIn = false;
  isAdminLoggedIn = false;
  filteredMovies: MovieDto[] = []; 
  bookedTicketCount: { [key: string]: number } = {};
  // Modal properties
  isModalOpen = false;
  selectedMovie: MovieDto | null = null; 
  ticketCount: number = 1; 

  // Add movie properties
  showAddMovieForm = false; 
  newMovie: MovieDto = {
    movie_Name: '',
    theatre_Name: '',
    no_of_Tickets_Available: 0,
    ticket_Status: '',
    show_Time: new Date()
  };

  // Edit ticket status properties
  isEditModalOpen = false;
  movieToEdit: string = '';
  newTicketStatus: string = '';

  constructor(private authService: AuthService, private searchService: SearchService) {}

  ngOnInit(): void {
    // Subscribe to the login status
    this.authService.isLoggedIn$.subscribe(loggedIn => {
      this.isUserLoggedIn = loggedIn;
    });

    // Subscribe to the admin login status
    this.authService.isAdminLoggedIn$.subscribe(adminLoggedIn => {
      this.isAdminLoggedIn = adminLoggedIn;
    });

    // Fetch all movies initially
    this.fetchAllMovies();

    // Subscribe to search queries from the SearchService
    this.searchService.search$.subscribe(query => {
      this.searchMovie(query);
    });
  }

  getMovieImage(movieName: string): string {
    const formattedName = movieName.toLowerCase().replace(/ /g, '_');
    return `assets/movies/${formattedName}.png`;
  }

  // Fetch movies from the backend
  private fetchAllMovies(): void {
    this.authService.getAllMovies().subscribe({
      next: (result) => {
        this.movies = result;
        this.filteredMovies = result; 
      },
      error: (err) => {
        console.error('Failed to fetch movies', err);
        alert('An error occurred while fetching movies.');
      }
    });
  }

  async fetchBookedTickets(movieName: string): Promise<void> {
    try {
      this.bookedTicketCount[movieName] = await firstValueFrom(this.authService.getBookedTickets(movieName));
    } catch (error) {
      alert('Error fetching booked tickets: '); // Consider logging the error
    }
  }

  onDeleteMovie(movieName: string): void {
    if (confirm(`Are you sure you want to delete the movie "${movieName}"?`)) {
      this.authService.deleteMovie(movieName).subscribe({
        next: (response) => {
          alert('Movie deleted successfully!');
          this.fetchAllMovies(); // Refresh the movie list
        },
        error: (err) => {
          console.error('Error deleting movie', err);
          alert('Error deleting movie: ' + err.message);
        }
      });
    }
  }
  // Method to handle movie search
  public searchMovie(query: string): void {
    if (query) {
      this.filteredMovies = this.movies.filter(movie => 
        movie.movie_Name.toLowerCase().includes(query.toLowerCase())
      );
    } else {
      this.filteredMovies = this.movies; 
    }
  }

  // Open booking modal
  openBookingModal(movie: MovieDto): void {
    this.selectedMovie = movie;
    this.isModalOpen = true;
  }

  // Close modal
  closeModal(): void {
    this.isModalOpen = false;
    this.ticketCount = 1; 
    this.isEditModalOpen = false; // Close edit modal
    this.movieToEdit = ''; // Reset movie name input
    this.newTicketStatus = ''; // Reset ticket status input
  }

  onBookTicket(movieTitle: string): void {
    if (this.isUserLoggedIn) {
      const movie = this.movies.find(m => m.movie_Name === movieTitle);
      if (movie) {
        this.openBookingModal(movie);
      }
    } else {
      alert('Please log in to book a ticket.');
    }
  }

  // Confirm booking logic
  async confirmBooking(): Promise<void> {
    if (this.selectedMovie) {
      try {
        const response = await firstValueFrom(this.authService.bookTickets(this.selectedMovie.movie_Name, this.ticketCount));
        alert(`Booking confirmed ${this.ticketCount} ticket(s) for ${this.selectedMovie.movie_Name}`);
        this.closeModal();
      } catch (error) {
        alert('Error booking tickets: ');
      }
    }
  }

  // Open edit modal for updating ticket status
  openEditModal(): void {
    this.isEditModalOpen = true;
  }

  // Confirm editing ticket status
  async confirmEdit(movieName: string): Promise<void> {
    try {
      const response = await firstValueFrom(this.authService.updateTicketStatus(movieName));
      alert(`Ticket status updated for: ${movieName}`);
      this.fetchAllMovies(); // Refresh movie list
      // Close any modal or reset state if needed
    } catch (error) {
      alert('Error updating ticket status: ');
    }
  }
  
  

  // Toggle add movie form visibility
  toggleAddMovieForm(): void {
    this.showAddMovieForm = !this.showAddMovieForm;
  }

 
  // Add movie logic
  onAddMovie(): void {
    this.authService.addMovie(this.newMovie).subscribe({
      next: (response) => {
        alert('Movie added successfully!');
        this.fetchAllMovies(); // Refresh the movie list
        this.toggleAddMovieForm(); // Close the form
        this.newMovie = { 
          movie_Name: '',
          theatre_Name: '',
          no_of_Tickets_Available: 0,
          ticket_Status: '',
          show_Time: new Date()
        };
      },
      error: (err) => {
        console.error('Error adding movie', err);
        alert('Error adding movie: ' + err.message);
      }
    });
  }
}
