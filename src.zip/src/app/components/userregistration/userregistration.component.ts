import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service'; // Adjust the path based on your structure
import { User } from '../../model/user.model';

@Component({
  selector: 'app-userregistration',
  templateUrl: './userregistration.component.html',
  styleUrls: ['./userregistration.component.css'],
})
export class UserregistrationComponent implements OnInit {
  user: User = {
    First_Name: '',
    Email: '',
    Password: '',
    Last_Name: '',
    Confrim_Password: '',
    Login_Id: ''
  };

  constructor(private userService: UserService) { }

  ngOnInit(): void {
  }

  onSubmit(): void {
    console.log(this.user);
    this.userService.registerUser(this.user).subscribe( 
      (response) => {
        console.log('Registration successful:', response);
      }
  
    )
  }
}

